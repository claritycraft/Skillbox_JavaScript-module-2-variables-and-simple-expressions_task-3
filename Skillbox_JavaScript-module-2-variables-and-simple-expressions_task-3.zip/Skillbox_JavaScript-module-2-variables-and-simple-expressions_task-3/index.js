// Сделайте код программы короче, используя инкремент.

let index = 0; // Счетчик

// Бегун 1
let runner1 = "Денис";
index++;
// index = index + 1;
console.log(index, runner1);

// Бегун 2
let runner2 = "Виктория";
index++;
// index = index + 1;
console.log(index, runner2);

// Бегун 3
let runner3 = "Антон";
index++;
// index = index + 1;
console.log(index, runner3);

// Бегун 4
let runner4 = "Лена";
index++;
// index = index + 1;
console.log(index, runner4);

// Бегун 5
let runner5 = "Никита";
// index = index + 1;
index++;
console.log(index, runner5);
